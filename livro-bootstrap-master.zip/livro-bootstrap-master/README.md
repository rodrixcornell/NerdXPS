Projetos do livro Bootstrap 3
============

Este projeto contém todo o código fonte do livro, no qual você usar como referência para o seu aprendizado. 

## Demo
A ser definido

## Arquivos

- **template** Contém os arquivos iniciais para a criação de um projeto Bootstrap do "zero"

- **Exemplos** Exemplos do livro 
	- **classe-container.html** Exemplo simples do uso desta classe, que deve ser usada para criar o conteúdo da página web
	- **grid-system-1.html** Um exemplo simples com o uso das classes para a definição de blocos
	- **grid-system-2.html** Exemplo contendo dois blocos de texto no qual assumem larguras diferentes de acordo com o tamanho do dispositivo.
	- **grid-system-3.html** Uso do offset
	- **grid-system-4.html** Uso de colunas aninhadas
	- **textos.html** Usado para exemplificar algumas partes da tipografia do html que o bootstrap melhora, como centralizar um texto, definir uma lista horizontal, entre outros.
	